# Coucou on the phone alone (stand-alone mode)

A new button on the first screen, **Use on this phone only**, starts Coucou without any computer. The phone itself plays the part of
the computer (`app/src/main/kotlin/com/coucou/android/local/`):

| File | What it does |
|---|---|
| `LocalLink.kt` | a `DesktopLink` that reports what the phone sees; Mochi, Home, the island, the Widgets and the Chat tab work unchanged on top of it |
| `CoucouNotificationListener.kt`, `PhoneFeed.kt` | reads the phone's notifications (memory only); WhatsApp has its own pill |
| `Weather.kt` | the weather for your city (Open-Meteo, no key) |
| `LocalChat.kt` | chat straight to the AI with your own key (kept in the Keystore) |
| `VoiceController.kt`, `VoiceIntents.kt`, `VoiceActions.kt` | tap the mic and speak: timer, alarm, open an app, read notifications, weather, search, or ask the AI. Arabic, English, French |
| `LocalStore.kt` | the stand-alone settings |
| `ui/LocalPanel.kt` | the card on Home: mic, notification access, city, key |

Not touched: Mochi's drawing, outfits, animations, sounds, the design system, the widgets and the pairing with a computer.
Small hooks in existing files: `AppModel.kt` (`Mode.LOCAL`, `startLocal`), `LinkStatus.kt`, `SettingsScreens.kt`, `PairingScreen.kt`,
`MainActivity.kt` (one line to show the card), `Notifications.kt` (one condition), `AndroidManifest.xml`.

Build without a computer: put the project in a GitHub repository, open Actions > standalone-apk > Run workflow, download the APK.
