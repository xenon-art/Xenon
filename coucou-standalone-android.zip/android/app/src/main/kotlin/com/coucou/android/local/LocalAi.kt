package com.coucou.android.local

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * The AI that runs on the tablet itself (no key, no server). The user gives the app one model file (a MediaPipe ".task" bundle such as
 * Gemma 3 1B), either by choosing it from the phone's storage or by pasting a direct link; it is kept in the app's private folder.
 * The model is loaded on first use and let go again after a few idle minutes, so it does not hold the tablet's memory for nothing.
 */
object LocalAi {
    enum class Template { GEMMA, CHATML }

    private const val MIN_BYTES = 20_000_000L
    private const val MAX_TOKENS = 1024
    private const val GEN_TIMEOUT_S = 300L
    private const val IDLE_MS = 4 * 60_000L

    @Volatile private var appContext: Context? = null
    private val lock = Any()
    private var engine: LlmInference? = null
    private val main = Handler(Looper.getMainLooper())
    private val releaseTask = Runnable { Thread({ release() }, "coucou-ai-release").apply { isDaemon = true; start() } }

    /** A model file is in place. */
    var hasModel by mutableStateOf(false); private set
    /** "name.task · 555 MB", or empty. */
    var modelLabel by mutableStateOf(""); private set
    /** What is happening now ("Copying 40%"), empty when nothing is. */
    var busyText by mutableStateOf(""); private set
    /** The last result worth telling the user (an error or "ready"). */
    var note by mutableStateOf(""); private set

    val context: Context? get() = appContext

    private fun ar() = Locale.getDefault().language == "ar"
    private fun s(en: String, arabic: String) = if (ar()) arabic else en

    fun init(context: Context) {
        if (appContext == null) appContext = context.applicationContext
        refresh()
    }

    private fun dir(ctx: Context) = File(ctx.filesDir, "ai").apply { mkdirs() }
    private fun modelFile(ctx: Context) = File(dir(ctx), "model.task")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("coucou_local_ai", Context.MODE_PRIVATE)

    fun refresh() {
        val ctx = appContext ?: return
        val f = modelFile(ctx)
        hasModel = f.isFile && f.length() >= MIN_BYTES
        modelLabel = if (hasModel) "${prefs(ctx).getString("name", "model.task")} · ${f.length() / 1_000_000} MB" else ""
    }

    /** Which prompt format the model expects, from its file name. */
    fun template(): Template {
        val ctx = appContext ?: return Template.GEMMA
        val name = prefs(ctx).getString("name", "") ?: ""
        return if (name.contains("qwen", ignoreCase = true)) Template.CHATML else Template.GEMMA
    }

    // ---- getting the model onto the tablet ----

    /** Copies the file the user chose (from the system file picker) into the app's private folder. */
    fun importModel(context: Context, uri: Uri) {
        init(context)
        if (busyText.isNotEmpty()) return
        val ctx = context.applicationContext
        Thread({ importNow(ctx, uri) }, "coucou-model-import").apply { isDaemon = true; start() }
    }

    private fun importNow(ctx: Context, uri: Uri) {
        try {
            busyText = s("Copying the model…", "جارٍ نسخ النموذج…")
            note = ""
            val (name, size) = nameAndSize(ctx, uri)
            if (size > 0 && ctx.filesDir.usableSpace < size + 100_000_000L) {
                fail(s("Not enough free storage for this model.", "لا توجد مساحة كافية على الجهاز لهذا النموذج."))
                return
            }
            val input = ctx.contentResolver.openInputStream(uri)
            if (input == null) { fail(s("I couldn't open that file.", "تعذر فتح هذا الملف.")); return }
            val tmp = File(dir(ctx), "model.part")
            input.use { copy(it, tmp, size) }
            install(ctx, tmp, name)
        } catch (e: Exception) {
            fail(s("Copy failed: ", "فشل النسخ: ") + (e.message ?: "").take(80))
        }
    }

    /** Downloads the model from a direct https link (a Hugging Face "resolve" link, for example). */
    fun downloadModel(context: Context, link: String) {
        init(context)
        if (busyText.isNotEmpty()) return
        val ctx = context.applicationContext
        val url = link.trim()
        if (!url.startsWith("https://")) { note = s("The link must start with https://", "يجب أن يبدأ الرابط بـ https://"); return }
        Thread({ downloadNow(ctx, url) }, "coucou-model-download").apply { isDaemon = true; start() }
    }

    private fun downloadNow(ctx: Context, url: String) {
        try {
            busyText = s("Downloading the model…", "جارٍ تنزيل النموذج…")
            note = ""
            val tmp = File(dir(ctx), "model.part")
            val name = url.substringBefore('?').substringAfterLast('/').ifBlank { "model.task" }
            var current = url
            var conn: HttpURLConnection? = null
            for (hop in 0..6) {
                val c = URL(current).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 15_000
                c.readTimeout = 30_000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) Coucou")
                val code = c.responseCode
                if (code in 300..399) {
                    val next = c.getHeaderField("Location")
                    c.disconnect()
                    if (next == null || !next.startsWith("https://")) { fail(s("The download link is not valid.", "رابط التنزيل غير صالح.")); return }
                    current = next
                    continue
                }
                if (code == 401 || code == 403) {
                    c.disconnect()
                    fail(s("This model is protected. Download it in the browser after accepting its license, then choose the file here.", "هذا النموذج محمي. نزّله من المتصفح بعد قبول الترخيص، ثم اخترِ الملف من هنا."))
                    return
                }
                if (code != 200) { c.disconnect(); fail(s("Download failed ($code).", "فشل التنزيل ($code).")); return }
                conn = c
                break
            }
            val c = conn
            if (c == null) { fail(s("Too many redirects.", "تحويلات كثيرة في الرابط.")); return }
            val size = c.contentLengthLong
            if (size > 0 && ctx.filesDir.usableSpace < size + 100_000_000L) {
                c.disconnect()
                fail(s("Not enough free storage for this model.", "لا توجد مساحة كافية على الجهاز لهذا النموذج."))
                return
            }
            c.inputStream.use { copy(it, tmp, size) }
            c.disconnect()
            install(ctx, tmp, name)
        } catch (e: Exception) {
            fail(s("Download failed: ", "فشل التنزيل: ") + (e.message ?: "").take(80))
        }
    }

    fun deleteModel() {
        val ctx = appContext ?: return
        release()
        modelFile(ctx).delete()
        refresh()
        note = ""
    }

    private fun nameAndSize(ctx: Context, uri: Uri): Pair<String, Long> {
        var name = "model.task"
        var size = -1L
        runCatching {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val z = c.getColumnIndex(OpenableColumns.SIZE)
                    if (n >= 0) name = c.getString(n) ?: name
                    if (z >= 0 && !c.isNull(z)) size = c.getLong(z)
                }
            }
        }
        return name to size
    }

    private fun copy(input: InputStream, to: File, total: Long) {
        val buf = ByteArray(256 * 1024)
        var done = 0L
        var lastPct = -1
        to.outputStream().use { out ->
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                done += n
                if (total > 0) {
                    val pct = (done * 100 / total).toInt()
                    if (pct != lastPct) { lastPct = pct; busyText = s("Working… $pct%", "جارٍ العمل… $pct%") }
                } else if (done % (16L * 1024 * 1024) < buf.size) {
                    busyText = s("Working… ${done / 1_000_000} MB", "جارٍ العمل… ${done / 1_000_000} MB")
                }
            }
        }
    }

    private fun install(ctx: Context, tmp: File, name: String) {
        if (tmp.length() < MIN_BYTES) {
            tmp.delete()
            fail(s("That file is too small to be a model.", "هذا الملف أصغر من أن يكون نموذجاً."))
            return
        }
        release()
        val dest = modelFile(ctx)
        dest.delete()
        if (!tmp.renameTo(dest)) { tmp.delete(); fail(s("Couldn't save the model.", "تعذر حفظ النموذج.")); return }
        prefs(ctx).edit().putString("name", name).apply()
        refresh()
        // Load it once now, so a model this version can't run is reported here and not in the middle of a chat.
        busyText = s("Checking the model…", "جارٍ فحص النموذج…")
        try {
            synchronized(lock) { ensureEngine(ctx) }
            busyText = ""
            note = s("The model is ready.", "النموذج جاهز.") + lowMemoryWarning(ctx, dest.length())
            main.postDelayed(releaseTask, IDLE_MS)
        } catch (e: Throwable) {
            busyText = ""
            note = s("The model was saved but could not be loaded: ", "تم حفظ النموذج لكن تعذر تشغيله: ") + (e.message ?: e.javaClass.simpleName).take(100)
        }
    }

    private fun lowMemoryWarning(ctx: Context, bytes: Long): String {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return if (mi.totalMem < 3_800_000_000L && bytes > 900_000_000L)
            s(" Note: this tablet has little memory, a smaller model will be steadier.", " تنبيه: ذاكرة الجهاز قليلة، نموذج أصغر سيكون أكثر ثباتاً.")
        else ""
    }

    private fun fail(message: String) { busyText = ""; note = message }

    // ---- running it ----

    private fun ensureEngine(ctx: Context): LlmInference {
        engine?.let { return it }
        val f = modelFile(ctx)
        check(f.isFile) { "no model file" }
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(f.absolutePath)
            .setMaxTokens(MAX_TOKENS)
            .setPreferredBackend(LlmInference.Backend.CPU)
            .build()
        val e = LlmInference.createFromOptions(ctx, options)
        engine = e
        return e
    }

    /** Lets the model go (frees its memory). Safe to call at any time. */
    fun release() {
        synchronized(lock) {
            runCatching { engine?.close() }
            engine = null
        }
    }

    /**
     * Writes the answer to [prompt]; [onDelta] gets each new piece as it is produced (from another thread). Blocks until the answer is
     * complete. One answer at a time.
     */
    fun generate(prompt: String, onDelta: (String) -> Unit, cancelled: () -> Boolean): String {
        val ctx = appContext ?: error("not ready")
        return synchronized(lock) {
            main.removeCallbacks(releaseTask)
            try {
                val llm = ensureEngine(ctx)
                val sessionOptions = LlmInferenceSession.LlmInferenceSessionOptions.builder()
                    .setTopK(40)
                    .setTemperature(0.7f)
                    .setRandomSeed(1)
                    .build()
                val session = LlmInferenceSession.createFromOptions(llm, sessionOptions)
                try {
                    session.addQueryChunk(prompt)
                    val out = StringBuilder()
                    val latch = CountDownLatch(1)
                    session.generateResponseAsync { partial, done ->
                        val piece = clean(partial ?: "")
                        if (piece.isNotEmpty() && !cancelled()) { out.append(piece); onDelta(piece) }
                        if (done) latch.countDown()
                    }
                    check(latch.await(GEN_TIMEOUT_S, TimeUnit.SECONDS)) { "the model took too long" }
                    out.toString().trim()
                } finally {
                    runCatching { session.close() }
                }
            } finally {
                main.postDelayed(releaseTask, IDLE_MS)
            }
        }
    }

    private fun clean(s: String) = s.replace("<end_of_turn>", "").replace("<start_of_turn>", "").replace("<|im_end|>", "").replace("<|im_start|>", "")
}
