package com.coucou.android.local

import android.content.Context
import android.os.Build
import com.coucou.android.link.ApprovalBook
import com.coucou.android.link.ChatModel
import com.coucou.android.link.DesktopLink
import com.coucou.android.link.LinkListener
import com.coucou.android.link.LinkState
import com.coucou.android.link.Protocol
import com.coucou.android.link.ServiceCard
import com.coucou.android.link.ServiceLine
import com.coucou.android.link.SessionInfo
import com.coucou.android.mochi.BotState
import java.util.Locale

/**
 * The phone as its own "computer". It plays the same part as the Windows or Linux link (it is a [DesktopLink], so Mochi, the Home
 * screen, the island, the Widgets and the Chat tab work unchanged), but what it reports comes from the phone itself:
 *
 *  - the phone's notifications (WhatsApp gets its own pill) from [CoucouNotificationListener],
 *  - the weather for the city the user set,
 *  - the chat, straight to the AI with the user's own key.
 *
 * Nothing here talks to a computer, and no coding agent is involved. It reports as connected as long as it runs.
 */
class LocalLink(
    private val context: Context,
    private val listener: LinkListener,
    private val store: LocalStore,
    private val clockMs: () -> Long = System::currentTimeMillis,
) : DesktopLink {
    override val approvals = ApprovalBook(clockMs)
    private val chat = LocalChat(store)
    private val messengers = listOf(
        Messenger("com.whatsapp", "integration_whatsapp", "WhatsApp"),
        Messenger("com.instagram", "integration_instagram", "Instagram"),
        Messenger("org.telegram", "integration_telegram", "Telegram"),
        Messenger("com.facebook.orca", "integration_messenger", "Messenger"),
    )
    private class Messenger(val pkgPrefix: String, val pillId: String, val label: String)
    private val arabic get() = Locale.getDefault().language == "ar"

    @Volatile private var running = false
    @Volatile private var weather: Weather.Report? = null
    @Volatile private var thinking = false
    private var worker: Thread? = null
    private var voiceSeq = 0

    private fun s(en: String, ar: String) = if (arabic) ar else en

    override fun start() {
        if (running) return
        running = true
        LocalAi.init(context)
        listener.onState(LinkState.CONNECTED)
        listener.onWelcome(Build.MODEL ?: "Phone", "android")
        listener.onCaps(setOf(Protocol.CAP_CHAT, Protocol.CAP_SERVICES, Protocol.CAP_DETAILS))
        listener.onChatModels(models())
        PhoneFeed.setListener { publish() }
        publish()
        worker = Thread({
            try {
                while (running) {
                    weather = Weather.fetch(store.city) ?: weather
                    publish()
                    Thread.sleep(WEATHER_EVERY_MS)
                }
            } catch (_: InterruptedException) { }
        }, "coucou-local").apply { isDaemon = true; start() }
    }

    override fun stop() {
        running = false
        PhoneFeed.setListener(null)
        worker?.interrupt()
        worker = null
        approvals.clear()
        listener.onState(LinkState.DISCONNECTED)
    }

    /** The city or the notification switch changed: look again now. */
    fun refresh() {
        Thread({ weather = Weather.fetch(store.city); publish() }, "coucou-local-refresh").apply { isDaemon = true; start() }
    }

    // ---- what Mochi shows ----

    private fun publish() {
        if (!running) return
        val now = clockMs()
        val sessions = ArrayList<SessionInfo>()

        if (thinking) sessions += SessionInfo("ai_local", s("Local AI", "الذكاء المحلي"), BotState.THINKING, s("Thinking", "يفكر"), 1, 2, now)

        if (store.watchNotifications) {
            val all = PhoneFeed.all()
            for (m in messengers) {
                val mine = all.filter { it.pkg.startsWith(m.pkgPrefix) }
                if (mine.isEmpty()) continue
                sessions += SessionInfo(
                    m.pillId, m.label, BotState.QUESTION,
                    s("${mine.size} new", "${mine.size} جديدة"), 0, 0, now,
                    steps = mine.take(5).map { line(it) }, finalLine = mine.first().text.ifBlank { null },
                )
            }
            val rest = all.filter { n -> messengers.none { n.pkg.startsWith(it.pkgPrefix) } }
            if (rest.isNotEmpty()) {
                sessions += SessionInfo(
                    "phone_notifications", s("Notifications", "الإشعارات"), BotState.QUESTION,
                    s("${rest.size} waiting", "${rest.size} بانتظارك"), 0, 0, now, color = "#F5A524",
                    steps = rest.take(5).map { line(it) }, finalLine = rest.first().text.ifBlank { null },
                )
            }
        }

        weather?.let {
            sessions += SessionInfo(
                "phone_weather", s("Weather", "الطقس"), BotState.IDLE,
                "${it.city} ${it.tempC}° · " + if (arabic) Weather.describeAr(it.code) else Weather.describe(it.code),
                0, 0, now, color = "#38BDF8",
            )
        }
        listener.onSessions(sessions)

        val cards = ArrayList<ServiceCard>()
        weather?.let {
            cards += ServiceCard(
                "phone_weather", s("Weather", "الطقس"), "${it.tempC}° · " + if (arabic) Weather.describeAr(it.code) else Weather.describe(it.code), null,
                listOf(ServiceLine(s("City", "المدينة"), it.city), ServiceLine(s("Wind", "الرياح"), "${it.windKmh} km/h")),
            )
        }
        if (store.watchNotifications) {
            cards += if (!PhoneFeed.listenerConnected) {
                ServiceCard("phone_notifications", s("Notifications", "الإشعارات"), s("Access is off", "الوصول متوقف"),
                    s("Turn on notification access for Coucou in Settings", "فعّل الوصول إلى الإشعارات لكوكو من الإعدادات"), emptyList())
            } else {
                val all = PhoneFeed.all()
                ServiceCard("phone_notifications", s("Notifications", "الإشعارات"), all.size.toString(), null,
                    all.take(6).map { ServiceLine(it.app, it.title.ifBlank { it.text }.take(60)) })
            }
        }
        listener.onServices(cards)
    }

    private fun line(i: PhoneFeed.Item) = "${i.app}: ${i.title.ifBlank { i.text }}".take(160)

    // ---- the DesktopLink the app calls ----

    override fun decide(fingerprint: String, allow: Boolean): Boolean {
        val r = approvals.claim(fingerprint) ?: return false
        listener.onApprovalResolved(r.fingerprint)
        return true
    }

    private fun models() = listOf(ChatModel("local", "local", s("AI on this device", "الذكاء الاصطناعي على الجهاز")))

    override fun chatModels() = listener.onChatModels(models())

    override fun chatSend(id: String, model: String, text: String): Boolean {
        if (!running) return false
        thinking = true
        publish()
        chat.send(id, model, text, object : LocalChat.Callback {
            override fun onDelta(id: String, text: String) = listener.onChatDelta(id, text)
            override fun onDone(id: String, text: String?) { thinking = false; publish(); listener.onChatDone(id, text) }
            override fun onError(id: String, reason: String, message: String) { thinking = false; publish(); listener.onChatError(id, reason, message) }
        })
        return true
    }

    override fun chatCancel(id: String) { chat.cancel(id); thinking = false; publish() }
    override fun chatReset() = chat.reset()

    /** A question from the voice: the same chat and history, the whole answer at once (null: it failed). */
    fun ask(text: String, done: (String?) -> Unit) {
        if (!running) { done(null); return }
        val id = "voice-${++voiceSeq}"
        val model = store.model
        val buf = StringBuilder()
        thinking = true
        publish()
        chat.send(id, model, text, object : LocalChat.Callback {
            override fun onDelta(id: String, text: String) { buf.append(text) }
            override fun onDone(id: String, text: String?) { thinking = false; publish(); done(text ?: buf.toString()) }
            override fun onError(id: String, reason: String, message: String) { thinking = false; publish(); done(null) }
        })
    }

    private companion object {
        const val WEATHER_EVERY_MS = 30L * 60_000L
    }
}
