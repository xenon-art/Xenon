package com.coucou.android.local

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Tap the mic, say what you want, Mochi does it and answers aloud. Speech recognition prefers the phone's offline model (the audio is
 * never recorded or stored here). Everything runs on the main thread except the AI call. The microphone permission is checked by the UI.
 */
class VoiceController(
    private val context: Context,
    private val actions: VoiceActions,
    /** Sends a free question to the AI and calls back with the answer (null: it failed). */
    private val ask: (text: String, done: (String?) -> Unit) -> Unit,
    private val onUpdate: (State, String) -> Unit,
) {
    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: Pair<String, Boolean>? = null

    val available: Boolean get() = SpeechRecognizer.isRecognitionAvailable(context)

    fun listen() {
        if (!available) { say("Speech recognition isn't available on this phone.", false); return }
        stop()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = onUpdate(State.LISTENING, "")
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onUpdate(State.LISTENING, it) }
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                release()
                if (text.isBlank()) onUpdate(State.IDLE, "") else handle(text)
            }
            override fun onError(error: Int) {
                release()
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> ""
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "I need the microphone permission."
                    else -> "I couldn't hear you."
                }
                onUpdate(State.IDLE, msg)
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true),
        )
    }

    fun stop() {
        release()
        tts?.stop()
        onUpdate(State.IDLE, "")
    }

    fun shutdown() {
        release()
        tts?.shutdown(); tts = null; ttsReady = false
    }

    private fun release() {
        recognizer?.let { runCatching { it.cancel(); it.destroy() } }
        recognizer = null
    }

    private fun handle(text: String) {
        val arabic = text.any { it in '\u0600'..'\u06FF' }
        val intent = VoiceParser.parse(text)
        onUpdate(State.THINKING, text)
        if (intent is VoiceIntent.Chat) {
            ask(text) { answer -> main.post { say(answer ?: if (arabic) "لم أستطع الوصول إلى الذكاء الاصطناعي. تحقق من المفتاح والإنترنت." else "I couldn't reach the AI. Check the key and the connection.", arabic) } }
            return
        }
        // Network work (weather) must not run on the main thread.
        Thread({
            val out = actions.run(intent, arabic)
            main.post { say(out.reply, arabic) }
        }, "coucou-voice-action").apply { isDaemon = true; start() }
    }

    private fun say(text: String, arabic: Boolean) {
        onUpdate(State.SPEAKING, text)
        val engine = tts
        if (engine == null) {
            pendingSpeech = text to arabic
            tts = TextToSpeech(context) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                pendingSpeech?.let { (t, a) -> pendingSpeech = null; speakNow(t, a) }
            }
        } else if (ttsReady) speakNow(text, arabic) else pendingSpeech = text to arabic
    }

    private fun speakNow(text: String, arabic: Boolean) {
        val e = tts ?: return
        if (e.setLanguage(if (arabic) Locale("ar") else Locale.getDefault()) < 0) e.setLanguage(Locale.getDefault())
        e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "coucou")
        main.postDelayed({ onUpdate(State.IDLE, text) }, (800L + text.length * 60L).coerceAtMost(20_000L))
    }
}
