package com.coucou.android.local

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** The weather from Open-Meteo (free, no key). Only the city name the user typed leaves the phone. */
object Weather {
    data class Report(val city: String, val tempC: Int, val code: Int, val windKmh: Int)

    fun fetch(city: String): Report? {
        val name = city.trim()
        if (name.isEmpty()) return null
        return try {
            val geo = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(name, "UTF-8")}&count=1"))
            val hit = geo.optJSONArray("results")?.optJSONObject(0) ?: return null
            val lat = hit.getDouble("latitude")
            val lon = hit.getDouble("longitude")
            val label = hit.optString("name", name)
            val w = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code,wind_speed_10m&timezone=auto"))
            val cur = w.getJSONObject("current")
            Report(label, Math.round(cur.getDouble("temperature_2m")).toInt(), cur.getInt("weather_code"), Math.round(cur.getDouble("wind_speed_10m")).toInt())
        } catch (_: Exception) {
            null
        }
    }

    /** WMO weather code -> a short English word (the UI strings around it are translated). */
    fun describe(code: Int): String = when (code) {
        0 -> "Clear"
        1, 2 -> "Mostly clear"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rain"
        in 71..77 -> "Snow"
        in 80..82 -> "Showers"
        85, 86 -> "Snow showers"
        95, 96, 99 -> "Thunderstorm"
        else -> "Unclear"
    }

    fun describeAr(code: Int): String = when (code) {
        0 -> "صافٍ"
        1, 2 -> "صافٍ في الغالب"
        3 -> "غائم"
        45, 48 -> "ضباب"
        in 51..57 -> "رذاذ"
        in 61..67 -> "مطر"
        in 71..77 -> "ثلج"
        in 80..82 -> "زخات مطر"
        85, 86 -> "زخات ثلج"
        95, 96, 99 -> "عاصفة رعدية"
        else -> "غير واضح"
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8_000
        c.readTimeout = 8_000
        try {
            if (c.responseCode != 200) throw java.io.IOException("http ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
