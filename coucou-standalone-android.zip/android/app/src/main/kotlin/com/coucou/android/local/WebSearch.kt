package com.coucou.android.local

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * A small web search for the on-device AI: when the tablet is online and the question needs facts, the top results (title and a few
 * lines) are handed to the model, which then answers from them. DuckDuckGo's plain HTML page first, Wikipedia as the fallback.
 * Only the search words leave the tablet; nothing about the user is sent.
 */
object WebSearch {
    data class Result(val title: String, val text: String)

    private const val UA = "Mozilla/5.0 (Linux; Android 11; Tablet) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

    fun isOnline(context: Context): Boolean = try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Exception) { false }

    // ---- when to search ----

    private val EXPLICIT = Regex("""^(ابحث عن|ابحث لي عن|ابحث|دور على|search for|search|google|cherche|recherche)\s+""", RegexOption.IGNORE_CASE)

    private val FRESH = listOf(
        "اخبار", "خبر", "اليوم", "الان", "حاليا", "اخر", "احدث", "سعر", "اسعار", "نتيجه", "نتايج", "مباراه", "مباريات", "ترتيب",
        "today", "latest", "news", "price", "score", "current", "currently", "right now", "recent", "who won",
        "aujourd", "actualite", "dernier", "prix",
    )

    private val QUESTION_STARTS = listOf(
        "من هو", "من هي", "من هم", "ما هو", "ما هي", "ما هم", "ماذا", "متى", "اين", "كم ", "كيف ", "لماذا", "هل ",
        "who ", "what ", "when ", "where ", "how many", "how much", "which ", "why ",
        "qui ", "quand ", "combien", "pourquoi", "quel",
    )

    private val CHIT_CHAT = listOf("كيف حالك", "كيفك", "شلونك", "how are you", "ca va", "comment ca va", "ما اسمك", "who are you", "من انت", "what is your name")

    fun shouldSearch(text: String): Boolean {
        if (EXPLICIT.containsMatchIn(text.trim())) return true
        val t = VoiceParser.normalize(text)
        if (t.split(' ').size < 2) return false
        if (CHIT_CHAT.any { t.contains(it) }) return false
        if (FRESH.any { t.contains(it) }) return true
        return QUESTION_STARTS.any { t.startsWith(it) }
    }

    fun queryFor(text: String): String =
        EXPLICIT.replace(text.trim(), "").trim().trimEnd('?', '؟', '.', '!').take(100)

    // ---- searching ----

    fun search(query: String): List<Result> {
        if (query.isBlank()) return emptyList()
        val fromDdg = duckDuckGo(query)
        if (fromDdg.isNotEmpty()) return fromDdg
        return wikipedia(query)
    }

    private val DDG_TITLE = Regex("""class="result__a"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
    private val DDG_SNIPPET = Regex("""class="result__snippet"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)

    private fun duckDuckGo(query: String): List<Result> {
        val body = get("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(query, "UTF-8")) ?: return emptyList()
        val titles = DDG_TITLE.findAll(body).map { plain(it.groupValues[1]) }.toList()
        val snippets = DDG_SNIPPET.findAll(body).map { plain(it.groupValues[1]) }.toList()
        val out = ArrayList<Result>()
        for (i in snippets.indices) {
            val snippet = snippets[i]
            if (snippet.isBlank()) continue
            out += Result(titles.getOrNull(i).orEmpty().take(80), snippet.take(300))
            if (out.size == 3) break
        }
        return out
    }

    private fun wikipedia(query: String): List<Result> {
        val lang = if (query.any { it in '\u0600'..'\u06FF' }) "ar" else "en"
        val url = "https://$lang.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=2&prop=extracts&exintro=1&explaintext=1" +
            "&exchars=450&format=json&utf8=1&gsrsearch=" + URLEncoder.encode(query, "UTF-8")
        val body = get(url) ?: return emptyList()
        return try {
            val pages = JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
            val list = ArrayList<JSONObject>()
            val keys = pages.keys()
            while (keys.hasNext()) pages.optJSONObject(keys.next())?.let { list += it }
            list.sortedBy { it.optInt("index", 99) }
                .map { Result(it.optString("title").take(80), it.optString("extract").replace(Regex("""\s+"""), " ").trim().take(450)) }
                .filter { it.text.isNotBlank() }
        } catch (_: Exception) { emptyList() }
    }

    private fun get(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6_000
        c.readTimeout = 8_000
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept-Language", "ar,en;q=0.8,fr;q=0.6")
        try {
            if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
        } finally {
            c.disconnect()
        }
    } catch (_: Exception) { null }

    private fun plain(html: String): String {
        var s = html.replace(Regex("<[^>]+>"), "")
        s = s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'").replace("&#39;", "'")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
        s = Regex("&#(\\d+);").replace(s) { m -> m.groupValues[1].toIntOrNull()?.let { String(Character.toChars(it)) } ?: "" }
        return s.replace(Regex("""\s+"""), " ").trim()
    }
}
