package com.coucou.android.local

import android.app.Notification
import android.content.ComponentName
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Lets Coucou see the phone's notifications (the user grants this in Android's "Notification access" screen). It only keeps the
 * app, title and text in memory for [PhoneFeed]; ongoing notifications (music players, Coucou's own) and group summaries are ignored.
 */
class CoucouNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        PhoneFeed.listenerConnected = true
        runCatching { activeNotifications?.forEach(::take) }
        PhoneFeed.poke()
    }

    override fun onListenerDisconnected() { PhoneFeed.listenerConnected = false; PhoneFeed.poke() }

    override fun onNotificationPosted(sbn: StatusBarNotification) = take(sbn)

    override fun onNotificationRemoved(sbn: StatusBarNotification) = PhoneFeed.remove(sbn.key)

    private fun take(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().take(120)
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty().take(400)
        if (title.isBlank() && text.isBlank()) return
        PhoneFeed.add(PhoneFeed.Item(sbn.key, sbn.packageName, appLabel(sbn.packageName), title, text, sbn.postTime))
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: PackageManager.NameNotFoundException) { pkg }

    companion object {
        fun component(context: android.content.Context) = ComponentName(context, CoucouNotificationListener::class.java)
    }
}
