package com.coucou.android.local

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock

/**
 * Does what a [VoiceIntent] asks, using the phone's own apps (clock, launcher, browser). It never sends a message or approves
 * anything by itself. The reply is written in Arabic when the user spoke Arabic, else in English.
 */
class VoiceActions(private val context: Context, private val store: LocalStore) {
    data class Outcome(val reply: String, val needsChat: String? = null)

    private var arabic = false
    private fun s(en: String, ar: String) = if (arabic) ar else en

    /** Runs [intent]; for [VoiceIntent.Chat] the outcome carries [Outcome.needsChat], for the caller to send to the AI. */
    fun run(intent: VoiceIntent, spokenArabic: Boolean): Outcome {
        arabic = spokenArabic
        return when (intent) {
            is VoiceIntent.Timer -> timer(intent.seconds)
            is VoiceIntent.Alarm -> alarm(intent.hour, intent.minute)
            is VoiceIntent.OpenApp -> openApp(intent.name)
            is VoiceIntent.Notifications -> notifications(intent.appHint)
            is VoiceIntent.WeatherNow -> weather(intent.city)
            is VoiceIntent.WebSearch -> search(intent.query)
            VoiceIntent.ClearNotifications -> { PhoneFeed.clear(); Outcome(s("Cleared.", "تم المسح.")) }
            is VoiceIntent.Chat -> Outcome("", needsChat = intent.text)
        }
    }

    private fun timer(seconds: Int): Outcome = start(
        Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_SKIP_UI, true),
        ok = s("Timer set for ${human(seconds)}.", "تم ضبط مؤقت لمدة ${humanAr(seconds)}."),
    )

    private fun alarm(h: Int, m: Int): Outcome = start(
        Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true),
        ok = s("Alarm set for %02d:%02d.", "تم ضبط المنبه على %02d:%02d.").format(h, m),
    )

    private fun openApp(name: String): Outcome {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val want = VoiceParser.normalize(name)
        val apps = pm.queryIntentActivities(launcher, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val hit = apps.firstOrNull { VoiceParser.normalize(it.first) == want }
            ?: apps.firstOrNull { VoiceParser.normalize(it.first).contains(want) || want.contains(VoiceParser.normalize(it.first)) }
            ?: return Outcome(s("I couldn't find an app called $name.", "لم أجد تطبيقاً باسم $name."))
        val go = pm.getLaunchIntentForPackage(hit.second) ?: return Outcome(s("I couldn't open ${hit.first}.", "لم أستطع فتح ${hit.first}."))
        return start(go, ok = s("Opening ${hit.first}.", "أفتح ${hit.first}."))
    }

    private fun notifications(appHint: String?): Outcome {
        if (!PhoneFeed.listenerConnected) {
            return Outcome(s("I can't see notifications yet. Turn on notification access for Coucou in Settings.", "لا أستطيع رؤية الإشعارات بعد. فعّل الوصول إلى الإشعارات لكوكو من الإعدادات."))
        }
        val n = PhoneFeed.count(appHint)
        if (n == 0) return Outcome(s("Nothing new.", "لا يوجد جديد."))
        val top = PhoneFeed.all().filter { appHint == null || it.pkg.startsWith(appHint) }.take(3)
        val lines = top.joinToString(" ") { "${it.app}: ${it.title.ifBlank { it.text }}." }
        return Outcome(s("You have $n. $lines", "لديك $n. $lines"))
    }

    private fun weather(city: String?): Outcome {
        val place = city?.takeIf { it.isNotBlank() } ?: store.city
        if (place.isBlank()) return Outcome(s("Tell me your city in Settings first.", "اكتب مدينتك في الإعدادات أولاً."))
        val r = Weather.fetch(place) ?: return Outcome(s("I couldn't get the weather for $place.", "لم أستطع جلب الطقس في $place."))
        return Outcome(s("${r.city}: ${r.tempC} degrees, ${Weather.describe(r.code).lowercase()}, wind ${r.windKmh} km/h.", "${r.city}: ${r.tempC} درجة، ${Weather.describeAr(r.code)}، الرياح ${r.windKmh} كم/س."))
    }

    private fun search(query: String): Outcome = start(
        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))),
        ok = s("Searching for $query.", "أبحث عن $query."),
    )

    private fun start(intent: Intent, ok: String): Outcome = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Outcome(ok)
    } catch (_: ActivityNotFoundException) {
        Outcome(s("No app on this phone can do that.", "لا يوجد تطبيق على هذا الهاتف يستطيع فعل ذلك."))
    } catch (_: SecurityException) {
        Outcome(s("Android didn't allow that.", "لم يسمح أندرويد بذلك."))
    }

    private fun human(seconds: Int): String = when {
        seconds % 3600 == 0 -> "${seconds / 3600} hour" + if (seconds / 3600 > 1) "s" else ""
        seconds % 60 == 0 -> "${seconds / 60} minute" + if (seconds / 60 > 1) "s" else ""
        else -> "$seconds seconds"
    }

    private fun humanAr(seconds: Int): String = when {
        seconds % 3600 == 0 -> "${seconds / 3600} ساعة"
        seconds % 60 == 0 -> "${seconds / 60} دقيقة"
        else -> "$seconds ثانية"
    }
}
