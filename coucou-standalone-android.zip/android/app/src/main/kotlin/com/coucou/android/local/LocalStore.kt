package com.coucou.android.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Settings of the stand-alone mode (the phone is its own "computer"). The AI key is encrypted with a key that never leaves the
 * Android Keystore, like the pairing in [com.coucou.android.app.SecureStore]. Nothing here is ever logged.
 */
class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("coucou_local", Context.MODE_PRIVATE)

    var city: String
        get() = prefs.getString("city", "") ?: ""
        set(v) { prefs.edit().putString("city", v.trim().take(80)).apply() }

    var model: String
        get() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) { prefs.edit().putString("model", v).apply() }

    var watchNotifications: Boolean
        get() = prefs.getBoolean("watch_notifications", true)
        set(v) { prefs.edit().putBoolean("watch_notifications", v).apply() }

    /** Was stand-alone mode on when the app last ran? Then it starts again by itself. */
    var enabled: Boolean
        get() = prefs.getBoolean("enabled", false)
        set(v) { prefs.edit().putBoolean("enabled", v).apply() }

    fun hasApiKey(): Boolean = prefs.getString(KEY_PREF, null) != null

    fun saveApiKey(key: String) {
        val clean = key.trim()
        if (clean.isEmpty()) { prefs.edit().remove(KEY_PREF).apply(); return }
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, secret()) }
        val ct = c.doFinal(clean.toByteArray(Charsets.UTF_8))
        prefs.edit().putString(KEY_PREF, Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)).apply()
    }

    fun loadApiKey(): String? {
        val blob = prefs.getString(KEY_PREF, null) ?: return null
        return try {
            val raw = Base64.decode(blob, Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, secret(), GCMParameterSpec(128, raw, 0, IV_BYTES))
            }
            String(c.doFinal(raw, IV_BYTES, raw.size - IV_BYTES), Charsets.UTF_8)
        } catch (_: Exception) {
            prefs.edit().remove(KEY_PREF).apply() // unreadable (key lost): start clean
            null
        }
    }

    private fun secret(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build(),
            )
        }.generateKey()
    }

    companion object {
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
        private const val ALIAS = "coucou_local_key"
        private const val KEY_PREF = "api_key"
        private const val IV_BYTES = 12
    }
}
