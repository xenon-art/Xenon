package com.coucou.android.local

import java.util.Locale

/**
 * Chat with the AI that runs on the tablet ([LocalAi]); no key and no AI server. When the tablet is online and the question needs facts,
 * a short web search is done first and its results are given to the model ([WebSearch]). The history lives in memory only.
 */
class LocalChat(@Suppress("unused") private val store: LocalStore) {
    interface Callback {
        fun onDelta(id: String, text: String)
        fun onDone(id: String, text: String?)
        fun onError(id: String, reason: String, message: String)
    }

    private class Turn(val role: String, val text: String)

    private val history = ArrayList<Turn>()
    @Volatile private var cancelledId: String? = null

    private fun s(en: String, ar: String) = if (Locale.getDefault().language == "ar") ar else en

    @Synchronized fun reset() { history.clear() }

    fun cancel(id: String) { cancelledId = id }

    /** Sends one message; the answer streams to [cb] from a background thread. [model] is not used: there is one model, on the tablet. */
    @Suppress("UNUSED_PARAMETER")
    fun send(id: String, model: String, text: String, cb: Callback) {
        if (!LocalAi.hasModel) {
            cb.onError(id, "off", s("Load the AI model first (Home, AI on this device).", "حمّل نموذج الذكاء الاصطناعي أولاً (الرئيسية ← الذكاء الاصطناعي على الجهاز)."))
            return
        }
        synchronized(this) { history.add(Turn("user", text)) }
        Thread({ run(id, text, cb) }, "coucou-local-chat").apply { isDaemon = true; start() }
    }

    private fun run(id: String, text: String, cb: Callback) {
        try {
            val web = webContext(text)
            val prompt = buildPrompt(text, web)
            val answer = LocalAi.generate(
                prompt,
                onDelta = { piece -> if (cancelledId != id) cb.onDelta(id, piece) },
                cancelled = { cancelledId == id },
            )
            if (cancelledId == id) { dropLastUser(); return }
            val final = answer.ifBlank { s("I have no answer for that.", "ليس لدي جواب على ذلك.") }
            synchronized(this) { history.add(Turn("assistant", final)) }
            cb.onDone(id, final)
        } catch (e: Throwable) {
            dropLastUser()
            if (cancelledId != id) {
                cb.onError(id, "error", s("The on-device model failed: ", "تعذر تشغيل النموذج على الجهاز: ") + (e.message ?: e.javaClass.simpleName).take(100))
            }
        }
    }

    /** The search results for [text], or null when it needs none, the tablet is offline, or nothing was found. */
    private fun webContext(text: String): String? {
        val ctx = LocalAi.context ?: return null
        if (!WebSearch.shouldSearch(text) || !WebSearch.isOnline(ctx)) return null
        val results = WebSearch.search(WebSearch.queryFor(text))
        if (results.isEmpty()) return null
        return results.joinToString("\n") { "- ${it.title}: ${it.text}" }.take(WEB_CHARS)
    }

    private fun buildPrompt(userText: String, web: String?): String {
        val arabic = userText.any { it in '\u0600'..'\u06FF' }
        val current = when {
            web == null -> userText
            arabic -> "معلومات من الإنترنت:\n$web\n\nاعتمد على المعلومات أعلاه إن كانت مفيدة وأجب بإيجاز. السؤال: $userText"
            else -> "Web results:\n$web\n\nUse them if they help and answer briefly. Question: $userText"
        }
        val prior = synchronized(this) {
            history.dropLast(1).takeLast(MAX_HISTORY).dropWhile { it.role != "user" }.map { it.role to it.text.take(HISTORY_CHARS) }
        }
        val messages = prior + ("user" to current)
        return when (LocalAi.template()) {
            LocalAi.Template.GEMMA -> gemma(messages)
            LocalAi.Template.CHATML -> chatml(messages)
        }
    }

    private fun gemma(messages: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        messages.forEachIndexed { i, (role, text) ->
            if (role == "user") {
                sb.append("<start_of_turn>user\n")
                if (i == 0) sb.append(SYSTEM).append("\n\n")
                sb.append(text).append("<end_of_turn>\n")
            } else {
                sb.append("<start_of_turn>model\n").append(text).append("<end_of_turn>\n")
            }
        }
        return sb.append("<start_of_turn>model\n").toString()
    }

    private fun chatml(messages: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(SYSTEM).append("<|im_end|>\n")
        for ((role, text) in messages) {
            sb.append("<|im_start|>").append(if (role == "user") "user" else "assistant").append("\n").append(text).append("<|im_end|>\n")
        }
        return sb.append("<|im_start|>assistant\n").toString()
    }

    @Synchronized private fun dropLastUser() { if (history.lastOrNull()?.role == "user") history.removeAt(history.size - 1) }

    companion object {
        private const val MAX_HISTORY = 6
        private const val HISTORY_CHARS = 300
        private const val WEB_CHARS = 900
        private const val SYSTEM = "You are Coucou, a small friendly assistant living on the user's tablet. Answer briefly, in the language the user writes in (Arabic or English), in plain text without markdown."
    }
}
