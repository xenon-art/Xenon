package com.coucou.android.local

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Chat straight from the phone to the Anthropic API with the user's own key (kept in the Keystore). Nothing goes to any other server.
 * The history lives in memory; the key is never logged.
 */
class LocalChat(private val store: LocalStore) {
    interface Callback {
        fun onDelta(id: String, text: String)
        fun onDone(id: String, text: String?)
        fun onError(id: String, reason: String, message: String)
    }

    private class Turn(val role: String, val text: String)

    private val history = ArrayList<Turn>()
    @Volatile private var current: HttpURLConnection? = null
    @Volatile private var cancelledId: String? = null

    @Synchronized fun reset() { history.clear() }

    fun cancel(id: String) {
        cancelledId = id
        runCatching { current?.disconnect() }
    }

    /** Sends one message; the answer streams to [cb] from a background thread. */
    fun send(id: String, model: String, text: String, cb: Callback) {
        val key = store.loadApiKey()
        if (key == null) { cb.onError(id, "off", "Add your API key in Settings first."); return }
        synchronized(this) { history.add(Turn("user", text)) }
        Thread({ run(id, model, key, cb) }, "coucou-local-chat").apply { isDaemon = true; start() }
    }

    private fun run(id: String, model: String, key: String, cb: Callback) {
        val answer = StringBuilder()
        try {
            val body = JSONObject()
                .put("model", model)
                .put("max_tokens", 1024)
                .put("stream", true)
                .put("system", SYSTEM)
                .put("messages", JSONArray().also { arr ->
                    synchronized(this) { history.takeLast(MAX_TURNS).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.text)) } }
                })
            val c = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("content-type", "application/json")
                setRequestProperty("x-api-key", key)
                setRequestProperty("anthropic-version", "2023-06-01")
            }
            current = c
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code != 200) {
                val reason = when (code) { 401, 403 -> "auth"; 429 -> "rate"; 529 -> "busy"; else -> "error" }
                dropLastUser()
                cb.onError(id, reason, when (reason) {
                    "auth" -> "The API key was refused."
                    "rate" -> "Too many requests. Try again in a moment."
                    "busy" -> "The service is busy. Try again."
                    else -> "The request failed ($code)."
                })
                return
            }
            c.inputStream.bufferedReader().useLines { lines ->
                for (line in lines) {
                    if (cancelledId == id) break
                    if (!line.startsWith("data:")) continue
                    val json = runCatching { JSONObject(line.removePrefix("data:").trim()) }.getOrNull() ?: continue
                    if (json.optString("type") != "content_block_delta") continue
                    val piece = json.optJSONObject("delta")?.optString("text").orEmpty()
                    if (piece.isNotEmpty()) { answer.append(piece); cb.onDelta(id, piece) }
                }
            }
            if (cancelledId == id) { dropLastUser(); return }
            synchronized(this) { history.add(Turn("assistant", answer.toString())) }
            cb.onDone(id, answer.toString())
        } catch (e: IOException) {
            if (cancelledId != id) { dropLastUser(); cb.onError(id, "network", "No connection to the AI service.") }
        } finally {
            current = null
        }
    }

    @Synchronized private fun dropLastUser() { if (history.lastOrNull()?.role == "user") history.removeAt(history.size - 1) }

    companion object {
        private const val MAX_TURNS = 20
        private const val SYSTEM = "You are Coucou, a small friendly companion living on the user's phone. Answer briefly, in the language the user writes in, in plain text without markdown."
    }
}
