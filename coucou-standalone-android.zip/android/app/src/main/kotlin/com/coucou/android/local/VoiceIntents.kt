package com.coucou.android.local

/**
 * What the user said, understood by plain rules (no network, no model): English, Arabic and French. Pure Kotlin, so it is unit-tested.
 * Anything it does not recognise becomes [Chat], which goes to the AI.
 */
sealed interface VoiceIntent {
    data class Timer(val seconds: Int) : VoiceIntent
    data class Alarm(val hour: Int, val minute: Int) : VoiceIntent
    data class OpenApp(val name: String) : VoiceIntent
    data class Notifications(val appHint: String?) : VoiceIntent
    data class WeatherNow(val city: String?) : VoiceIntent
    data class WebSearch(val query: String) : VoiceIntent
    data object ClearNotifications : VoiceIntent
    data class Chat(val text: String) : VoiceIntent
}

object VoiceParser {
    fun parse(raw: String): VoiceIntent {
        val t = normalize(raw)
        if (t.isBlank()) return VoiceIntent.Chat(raw.trim())

        timer(t)?.let { return it }
        alarm(t)?.let { return it }

        if (has(t, CLEAR) && has(t, NOTIF)) return VoiceIntent.ClearNotifications
        if (has(t, NOTIF) && (has(t, READ) || has(t, ANY_NEW) || t.split(' ').size <= 3)) {
            val app = APP_HINTS.entries.firstOrNull { (k, _) -> t.contains(k) }?.value
            return VoiceIntent.Notifications(app)
        }
        if (has(t, WEATHER)) return VoiceIntent.WeatherNow(cityAfter(t))

        val open = after(t, OPEN)
        if (open != null && open.isNotBlank()) return VoiceIntent.OpenApp(open)

        val search = after(t, SEARCH)
        if (search != null && search.isNotBlank()) return VoiceIntent.WebSearch(search)

        return VoiceIntent.Chat(raw.trim())
    }

    // ---- timers and alarms ----

    private fun timer(t: String): VoiceIntent.Timer? {
        if (!has(t, TIMER)) return null
        var secs = 0
        val re = Regex("""(\d+)\s*(hours?|hrs?|h|heures?|ساعات?|ساعه|minutes?|mins?|min|دقيقه|دقائق|دقايق|seconds?|secs?|secondes?|ثانيه|ثواني)""")
        for (m in re.findAll(t)) {
            val n = m.groupValues[1].toIntOrNull() ?: continue
            val u = m.groupValues[2]
            secs += when {
                u.startsWith("h") || u.startsWith("ساع") -> n * 3600
                u.startsWith("sec") || u.startsWith("ثان") -> n
                else -> n * 60
            }
        }
        if (secs == 0) {
            if (has(t, listOf("half an hour", "نصف ساعه", "demi heure", "demi-heure"))) secs = 1800
            else if (has(t, listOf("an hour", "ساعه", "une heure"))) secs = 3600
        }
        return if (secs in 1..86_400) VoiceIntent.Timer(secs) else null
    }

    private fun alarm(t: String): VoiceIntent.Alarm? {
        if (!has(t, ALARM)) return null
        // "7:30", "7 30", "at 7", "الساعة 7"; "pm"/"م"/"مساء" move it to the afternoon.
        val m = Regex("""(\d{1,2})(?:\s*[:h.]\s*|\s+)?(\d{2})?""").find(t.replace(Regex("""\b(alarm|wake|set)\b"""), " ")) ?: return null
        var h = m.groupValues[1].toIntOrNull() ?: return null
        val min = m.groupValues[2].toIntOrNull() ?: 0
        if (h > 23 || min > 59) return null
        val pm = has(t, listOf("pm", "p m", "مساء", "مساءا", "بعد الظهر", "du soir", "de l apres midi"))
        if (pm && h in 1..11) h += 12
        return VoiceIntent.Alarm(h, min)
    }

    // ---- helpers ----

    /** Lower case, Arabic digits to ASCII, diacritics and punctuation out, so the word lists stay short. */
    fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            when (ch) {
                in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
                'أ', 'إ', 'آ' -> sb.append('ا')
                'ة' -> sb.append('ه')
                'é', 'è', 'ê', 'ë' -> sb.append('e')
                'à', 'â' -> sb.append('a')
                'ç' -> sb.append('c')
                'î', 'ï' -> sb.append('i')
                'ô' -> sb.append('o')
                'ù', 'û' -> sb.append('u')
                '\u064B', '\u064C', '\u064D', '\u064E', '\u064F', '\u0650', '\u0651', '\u0652', '\u0640' -> {}
                '\'', '’', '?', '!', '.', ',', '،', '؟' -> sb.append(if (ch == '.') '.' else ' ')
                else -> sb.append(ch)
            }
        }
        return sb.toString().replace(Regex("""\s+"""), " ").trim()
    }

    private fun has(t: String, words: List<String>) = words.any { t.contains(it) }

    /** The text after the first trigger word, or null. */
    private fun after(t: String, triggers: List<String>): String? {
        for (w in triggers) {
            val i = t.indexOf("$w ")
            if (i == 0 || (i > 0 && t[i - 1] == ' ')) return t.substring(i + w.length).trim().removePrefix("ال").trim()
        }
        return null
    }

    private fun cityAfter(t: String): String? {
        for (w in listOf(" in ", " a ", " à ", " في ", " ب")) {
            val i = t.indexOf(w)
            if (i >= 0) return t.substring(i + w.length).trim().ifBlank { null }
        }
        return null
    }

    private val TIMER = listOf("timer", "minuteur", "مؤقت", "عداد", "countdown", "remind me in", "ذكرني بعد", "rappelle moi dans")
    private val ALARM = listOf("alarm", "wake me", "reveil", "réveil", "منبه", "نبهني", "صحيني", "ايقظني")
    private val NOTIF = listOf("notification", "notifications", "messages", "message", "اشعار", "اشعارات", "رسائل", "رسايل", "جديد")
    private val READ = listOf("read", "tell", "what", "any", "check", "lis", "quoi", "اقرا", "اقرأ", "ايش", "شو", "هل", "ماذا", "ما هي", "قل لي")
    private val ANY_NEW = listOf("new", "nouveau", "nouveaux", "جديد", "وصل", "وصلت")
    private val CLEAR = listOf("clear", "dismiss", "efface", "امسح", "احذف", "نظف")
    private val WEATHER = listOf("weather", "temperature", "forecast", "meteo", "météo", "quel temps", "الطقس", "طقس", "الجو", "حراره", "درجه الحراره")
    private val OPEN = listOf("open", "launch", "ouvre", "lance", "افتح", "شغل")
    private val SEARCH = listOf("search for", "search", "google", "cherche", "recherche", "ابحث عن", "ابحث", "دور على")

    private val APP_HINTS = mapOf(
        "whatsapp" to "com.whatsapp", "واتساب" to "com.whatsapp", "واتس" to "com.whatsapp",
        "telegram" to "org.telegram", "تيليجرام" to "org.telegram", "تلغرام" to "org.telegram",
        "gmail" to "com.google.android.gm", "جيميل" to "com.google.android.gm",
        "instagram" to "com.instagram", "انستغرام" to "com.instagram", "انستا" to "com.instagram",
    )
}
