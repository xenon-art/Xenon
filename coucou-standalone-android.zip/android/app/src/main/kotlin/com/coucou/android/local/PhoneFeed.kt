package com.coucou.android.local

/**
 * What the notification listener saw, kept in memory only (never written to disk, never logged), newest first.
 * The listener writes, [LocalLink] reads and turns it into Mochi's pills.
 */
object PhoneFeed {
    data class Item(val key: String, val pkg: String, val app: String, val title: String, val text: String, val atMs: Long)

    private const val MAX = 40
    private val items = ArrayList<Item>()
    @Volatile private var listener: (() -> Unit)? = null
    @Volatile var listenerConnected: Boolean = false

    fun setListener(l: (() -> Unit)?) { listener = l }

    @Synchronized fun add(i: Item) {
        items.removeAll { it.key == i.key }
        items.add(0, i)
        while (items.size > MAX) items.removeAt(items.size - 1)
        listener?.invoke()
    }

    @Synchronized fun remove(key: String) {
        if (items.removeAll { it.key == key }) listener?.invoke()
    }

    /** The listener connected or disconnected: let the link say so. */
    fun poke() { listener?.invoke() }

    @Synchronized fun clear() { items.clear(); listener?.invoke() }

    @Synchronized fun all(): List<Item> = items.toList()

    @Synchronized fun count(pkgPrefix: String? = null): Int =
        if (pkgPrefix == null) items.size else items.count { it.pkg.startsWith(pkgPrefix) }

    /** The newest item, optionally of one app. */
    @Synchronized fun latest(pkgPrefix: String? = null): Item? =
        if (pkgPrefix == null) items.firstOrNull() else items.firstOrNull { it.pkg.startsWith(pkgPrefix) }
}
