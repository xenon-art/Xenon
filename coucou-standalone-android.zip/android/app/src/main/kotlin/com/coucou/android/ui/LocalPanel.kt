package com.coucou.android.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import java.util.Locale
import com.coucou.android.R
import com.coucou.android.app.AppModel
import com.coucou.android.core.Spacing
import com.coucou.android.core.TypeScale
import com.coucou.android.local.LocalAi
import com.coucou.android.local.PhoneFeed
import com.coucou.android.local.VoiceController

/**
 * Home's card in stand-alone mode: talk to Mochi, see whether the phone's notifications are being watched, and the two settings it needs
 * (the city for the weather and the AI key). Everything is kept on this phone.
 */
@Composable
fun LocalPanel(model: AppModel) {
    val t = tokens()
    val context = LocalContext.current
    var city by remember { mutableStateOf(model.localStore.city) }
    var modelLink by remember { mutableStateOf("") }
    val isAr = remember { Locale.getDefault().language == "ar" }
    fun tr(en: String, ar: String) = if (isAr) ar else en
    LaunchedEffect(Unit) { LocalAi.init(context) }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) LocalAi.importModel(context, uri)
    }
    var micDenied by remember { mutableStateOf(false) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        micDenied = !granted
        if (granted) model.voiceListen()
    }
    val busy = model.voiceState != VoiceController.State.IDLE
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = t.text.c(), unfocusedTextColor = t.text.c(), cursorColor = t.text.c(),
        focusedBorderColor = t.text.c(), unfocusedBorderColor = t.line.c(),
    )

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionHeading(stringResource(R.string.local_title))
        Panel {
            Column(Modifier.fillMaxWidth().padding(Spacing.INSIDE.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PillButton(
                    text = stringResource(
                        when (model.voiceState) {
                            VoiceController.State.IDLE -> R.string.local_talk
                            VoiceController.State.LISTENING -> R.string.local_listening
                            VoiceController.State.THINKING -> R.string.local_thinking
                            VoiceController.State.SPEAKING -> R.string.local_stop
                        },
                    ),
                    onClick = {
                        if (busy) model.voiceStop()
                        else if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) model.voiceListen()
                        else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    modifier = Modifier.fillMaxWidth(), kind = PillKind.PRIMARY,
                )
                if (micDenied) Text(stringResource(R.string.local_mic_denied), style = TypeScale.SECONDARY.style(t.textDim.c()))
                if (model.voiceText.isNotBlank()) Text(model.voiceText, style = TypeScale.BODY.style(t.text.c()))

                Text(
                    stringResource(if (PhoneFeed.listenerConnected) R.string.local_notif_on else R.string.local_notif_off),
                    style = TypeScale.BODY.style(t.textDim.c()),
                )
                if (!PhoneFeed.listenerConnected) {
                    PillButton(
                        stringResource(R.string.local_notif_open),
                        { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                        Modifier.fillMaxWidth(),
                    )
                }

                OutlinedTextField(
                    city, { city = it }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp),
                    label = { Text(stringResource(R.string.local_city)) }, colors = fieldColors,
                )
                Text(tr("AI on this device (no key, no server)", "الذكاء الاصطناعي على الجهاز (بدون مفتاح وبدون خادم)"), style = TypeScale.BODY.style(t.text.c()))
                Text(
                    when {
                        LocalAi.busyText.isNotEmpty() -> LocalAi.busyText
                        LocalAi.hasModel -> tr("Model ready: ", "النموذج جاهز: ") + LocalAi.modelLabel
                        else -> tr(
                            "No model yet. Download gemma3-1b-it-int4.task from Hugging Face (litert-community/Gemma3-1B-IT) in your browser, then choose the file here.",
                            "لا يوجد نموذج بعد. نزّل الملف gemma3-1b-it-int4.task من موقع Hugging Face (litert-community/Gemma3-1B-IT) عبر المتصفح، ثم اخترِ الملف من هنا.",
                        )
                    },
                    style = TypeScale.SECONDARY.style(t.textDim.c()),
                )
                if (LocalAi.note.isNotEmpty()) Text(LocalAi.note, style = TypeScale.SECONDARY.style(t.textDim.c()))
                if (LocalAi.busyText.isEmpty()) {
                    PillButton(
                        tr("Choose the model file", "اختيار ملف النموذج"),
                        { modelPicker.launch(arrayOf("*/*")) },
                        Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        modelLink, { modelLink = it }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp),
                        label = { Text(tr("Or a direct download link (https)", "أو رابط تنزيل مباشر (https)")) }, colors = fieldColors,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    )
                    if (modelLink.isNotBlank()) {
                        PillButton(tr("Download from the link", "تنزيل من الرابط"), { LocalAi.downloadModel(context, modelLink); modelLink = "" }, Modifier.fillMaxWidth())
                    }
                    if (LocalAi.hasModel) {
                        PillButton(tr("Delete the model", "حذف النموذج"), { LocalAi.deleteModel() }, Modifier.fillMaxWidth())
                    }
                }
                PillButton(
                    stringResource(R.string.local_save),
                    {
                        model.localStore.city = city
                        model.localChanged()
                    },
                    Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
