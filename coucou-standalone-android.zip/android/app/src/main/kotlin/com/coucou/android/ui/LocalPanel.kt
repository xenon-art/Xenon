package com.coucou.android.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.coucou.android.R
import com.coucou.android.app.AppModel
import com.coucou.android.core.Spacing
import com.coucou.android.core.TypeScale
import com.coucou.android.local.PhoneFeed
import com.coucou.android.local.VoiceController

/**
 * Home's card in stand-alone mode: talk to Mochi, see whether the phone's notifications are being watched, and the two settings it needs
 * (the city for the weather and the AI key). Everything is kept on this phone.
 */
@Composable
fun LocalPanel(model: AppModel) {
    val t = tokens()
    val context = LocalContext.current
    var city by remember { mutableStateOf(model.localStore.city) }
    var key by remember { mutableStateOf("") }
    var keySaved by remember { mutableStateOf(model.localStore.hasApiKey()) }
    var micDenied by remember { mutableStateOf(false) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        micDenied = !granted
        if (granted) model.voiceListen()
    }
    val busy = model.voiceState != VoiceController.State.IDLE
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = t.text.c(), unfocusedTextColor = t.text.c(), cursorColor = t.text.c(),
        focusedBorderColor = t.text.c(), unfocusedBorderColor = t.line.c(),
    )

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionHeading(stringResource(R.string.local_title))
        Panel {
            Column(Modifier.fillMaxWidth().padding(Spacing.INSIDE.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PillButton(
                    text = stringResource(
                        when (model.voiceState) {
                            VoiceController.State.IDLE -> R.string.local_talk
                            VoiceController.State.LISTENING -> R.string.local_listening
                            VoiceController.State.THINKING -> R.string.local_thinking
                            VoiceController.State.SPEAKING -> R.string.local_stop
                        },
                    ),
                    onClick = {
                        if (busy) model.voiceStop()
                        else if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) model.voiceListen()
                        else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    modifier = Modifier.fillMaxWidth(), kind = PillKind.PRIMARY,
                )
                if (micDenied) Text(stringResource(R.string.local_mic_denied), style = TypeScale.SECONDARY.style(t.textDim.c()))
                if (model.voiceText.isNotBlank()) Text(model.voiceText, style = TypeScale.BODY.style(t.text.c()))

                Text(
                    stringResource(if (PhoneFeed.listenerConnected) R.string.local_notif_on else R.string.local_notif_off),
                    style = TypeScale.BODY.style(t.textDim.c()),
                )
                if (!PhoneFeed.listenerConnected) {
                    PillButton(
                        stringResource(R.string.local_notif_open),
                        { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                        Modifier.fillMaxWidth(),
                    )
                }

                OutlinedTextField(
                    city, { city = it }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp),
                    label = { Text(stringResource(R.string.local_city)) }, colors = fieldColors,
                )
                OutlinedTextField(
                    key, { key = it }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp),
                    label = { Text(stringResource(R.string.local_key)) }, colors = fieldColors,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
                if (keySaved && key.isBlank()) Text(stringResource(R.string.local_key_saved), style = TypeScale.SECONDARY.style(t.textDim.c()))
                PillButton(
                    stringResource(R.string.local_save),
                    {
                        model.localStore.city = city
                        if (key.isNotBlank()) { model.localStore.saveApiKey(key); key = ""; keySaved = true }
                        model.localChanged()
                    },
                    Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
