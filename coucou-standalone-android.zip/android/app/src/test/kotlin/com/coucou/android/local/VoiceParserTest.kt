package com.coucou.android.local

import org.junit.Assert.assertEquals
import org.junit.Test

class VoiceParserTest {
    private fun p(s: String) = VoiceParser.parse(s)

    @Test fun timers() {
        assertEquals(VoiceIntent.Timer(300), p("set a timer for 5 minutes"))
        assertEquals(VoiceIntent.Timer(9000), p("timer 2 hours 30 minutes"))
        assertEquals(VoiceIntent.Timer(600), p("مؤقت ١٠ دقائق"))
        assertEquals(VoiceIntent.Timer(1800), p("minuteur demi heure"))
    }

    @Test fun alarms() {
        assertEquals(VoiceIntent.Alarm(19, 30), p("set an alarm for 7:30 pm"))
        assertEquals(VoiceIntent.Alarm(7, 0), p("wake me at 7"))
        assertEquals(VoiceIntent.Alarm(6, 0), p("نبهني الساعة 6"))
    }

    @Test fun weather() {
        assertEquals(VoiceIntent.WeatherNow("cairo"), p("what's the weather in Cairo"))
        assertEquals(VoiceIntent.WeatherNow(null), p("كيف الطقس"))
    }

    @Test fun notifications() {
        assertEquals(VoiceIntent.Notifications("com.whatsapp"), p("any new whatsapp messages"))
        assertEquals(VoiceIntent.Notifications(null), p("اقرا الاشعارات"))
        assertEquals(VoiceIntent.ClearNotifications, p("clear my notifications"))
    }

    @Test fun apps_and_search() {
        assertEquals(VoiceIntent.OpenApp("whatsapp"), p("open WhatsApp"))
        assertEquals(VoiceIntent.WebSearch("cats"), p("search for cats"))
    }

    @Test fun everything_else_goes_to_the_ai() {
        assertEquals(VoiceIntent.Chat("tell me a joke"), p("tell me a joke"))
    }
}
